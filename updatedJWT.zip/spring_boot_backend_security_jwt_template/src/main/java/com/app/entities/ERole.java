package com.app.entities;

public enum ERole {
	ADMIN,CUSTOMER,HOTEL_OWNER
}
