package com.app.entities;

public enum PackageType 
{
	SILVER,GOLD
}
